/*eslint-disable*/
import React , { Component } from 'react';
import { Button, Row,  Label, Col} from 'reactstrap';
import { Control, Form, Errors } from 'react-redux-form';



var ReactCSSTransitionGroup = require('react-addons-css-transition-group');
const required = (val) => val && val.length;
const maxLength = (len) => (val) => !(val) || (val.length <= len);
const minLength = (len) => (val) => {if(val>0){
    return  val && (val.length >= len);
}else{
    return true;
}

};
const isNumber = (val) => !isNaN(Number(val));
class Add_restaurant extends Component{
        constructor(props){
            super(props);
            this.handleSubmit = this.handleSubmit.bind(this);
            
            
        }

      
        
        
        handleSubmit(values) {
            console.log('Current State is: ' + JSON.stringify(values));
            alert('Current State is: ' + JSON.stringify(values));
            //this.props.resetregisterform();
        }
        render(){
            return(
                
                <ReactCSSTransitionGroup transitionName = "example"
                    transitionAppear = {true} transitionAppearTimeout = {10000}
                    transitionEnter = {true} transitionEnterTimeout={1000} transitionLeave = {true} transitionLeaveTimeout={1000}>
                    <div className="container padd1">
                                          
                        <div className="row justify-content-around">
                            <div className="col-8 col-md-8 mx-auto">
                                
                                    <div className="mx-auto center "><h3><b><u>ADD YOUR RESTAURANT</u></b></h3></div>
                                    <div className="row row-content">
                                        <div className="col-12 col-md-9 centerleft1">
                                            <Form model="register" onSubmit={(values) => this.handleSubmit(values)}>

                                        

                                            <Row className="form-group">
                                                <Label htmlfor="restname" md={4}><b>Restaurant Name </b></Label>
                                                    
                                                    <Col md={8}>
                                                   
                                                    <Control.text model=".restname" id="restname" name="restname"
                                                            placeholder="Restaurant Name"
                                                            className="form-control "
                                                            validators={{
                                                                required,minLength: minLength(5),maxLength:  maxLength(50)
                                                            }}
                                                            />
                                                            <Errors
                                                            className="text-danger"
                                                            model=".restname"
                                                            show="touched"
                                                            messages={{
                                                                required: 'Required\n',
                                                                minLength: 'Must be greater than 5 characters',
                                                                maxLength: 'must be 50 characters or less'
                                                            }}/>

                                                            </Col>

                                                        
                                                               
                                                </Row>
                                                            
                                                
                                                <Row className="form-group">
                                                    <Col md={{size: 6, offset: 2}}>
                                                        <div className="form-check">
                                                            <Label>                                                         
                                                                <strong>Cuisine Type:</strong>
                                                            </Label>
                                                        </div>
                                                    </Col>
                                                    <Col md={{size: 3, offset: 1}}>
                                                        <Control.select model=".cuisineType" name="cuisineType"
                                                            className="form-control">
                                                            <option>Desi</option>
                                                            <option>Western</option>
                                                            <option>Mexican.</option>
                                                            <option>Italian</option>
                                                            <option>Chinese</option>
                                                            
                                                            
                                                        </Control.select>
                                                    </Col>
                                                </Row>




                                                <Row className="form-group">
                                                    <Label htmlFor="websit" md={4}><b>Website (If any)</b></Label>
                                                        <Col md={8}>
                                                            <Control.text model=".websit" id="websit" name="websit"
                                                                placeholder="Website"
                                                                className="form-control"
                                                                validators={{
                                                                    required,minLength: minLength(3)
                                                                }}
                                                                />
                                                                <Errors
                                                                    className="text-danger"
                                                                    model=".websit"
                                                                    show="touched"
                                                                    messages={{
                                                                        minLength: 'Must be greater than 3 numbers',
                                                                        
                                                                        
                                                                }}/>
                                                                
                                                        </Col>
                                                </Row>

                                                <Row className="form-group">
                                                    <Label htmlFor="rate" md={4}><b>Rating</b></Label>
                                                        <Col md={8}>
                                                            <Control.text model=".rate" id="rate" name="rate"
                                                                placeholder="Rating"
                                                                className="form-control"
                                                                validators={{
                                                                    required, isNumber
                                                                }}
                                                                />
                                                                <Errors
                                                                    className="text-danger"
                                                                    model=".rate"
                                                                    show="touched"
                                                                    messages={{
                                                                        required: 'Required\n',
                                                                        minLength: 'Must be a number between 1-5',
                                                            
                                                                }}/>
                                                                
                                                        </Col>
                                                </Row>

                                         

                                                <Row className="form-group">
                                                    <Label htmlFor="contnum" md={4}><b>Contact Number</b></Label>
                                                        <Col md={8}>
                                                            <Control.text model=".contnum" id="contnum" name="contnum"
                                                                placeholder="Cont. Number"
                                                                className="form-control"
                                                                validators={{
                                                                    required,minLength: minLength(13),maxLength:  maxLength(20), isNumber
                                                                }}
                                                                />
                                                                <Errors
                                                                    className="text-danger"
                                                                    model=".contnum"
                                                                    show="touched"
                                                                    messages={{
                                                                        required: 'Required\n',
                                                                        minLength: 'Must be 13 digits',
                                                                        maxLength: 'Must be 13 fixed'
                                                            
                                                                }}/>
                                                                
                                                        </Col>
                                                </Row>

                                                <Row className="form-group">
                                                        <Label htmlFor="addr" md={4}><b>Address</b></Label>
                                                        <Col md={8}>
                                                            <Control.text model=".addr" id="addr" name="addr"
                                                                placeholder="Address"
                                                                className="form-control"
                                                                validators={{
                                                                    required,minLength: minLength(10),maxLength:  maxLength(50)
                                                                }}
                                                            />
                                                            <Errors
                                                                    className="text-danger"
                                                                    model=".addr"
                                                                    show="touched"
                                                                    messages={{
                                                                    required: 'Required\n',
                                                                    minLength: 'Must be 10 digits',
                                                                    maxLength: 'Must be 50 fixed'
                                                                }}/>
                                                                
                                                        </Col>
                                                </Row>
                                                


                                               

                                                <Row className="form-group">
                                                    <Col md={{size: 10, offset: 6}}>
                                                        <Button type="submit" color="primary">
                                                            <b>Press to Add</b>
                                                            
                                                        </Button>
                                                    </Col>



                                                </Row>


                                                
                                                
                                            </Form>     
                                        </div>
                                        

                                    </div>
                            
                            </div>
                        </div>  
                        
                    </div>
                </ReactCSSTransitionGroup>
               
            );
       }
            
    
    }

export default Add_restaurant;
