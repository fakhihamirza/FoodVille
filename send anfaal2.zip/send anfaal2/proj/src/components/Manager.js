/*eslint-disable*/
import React, { Component } from 'react';
import { Card, CardImg, CardTitle, CardHeader, Breadcrumb, BreadcrumbItem, CardBody, CardText ,Button, Media} from 'reactstrap';
import Tabs from "./tab/Tabs"; 
const baseUrl='http://localhost:3003/'

function Rendermanagersitem({ rest}){
    const restaurant =rest.map((res)=>{
        return(
           
            <div key={res.Restaurant_ID} label={res.Rest_Name} >
                <Card className="cards bord" body  style={{borderColor: '#0000' }}>
                    <img className="cut" src={baseUrl + res.img_src}/>   
                    <CardTitle><h1 className="tfont"><b>Restaurant Name: </b>{res.Rest_Name}</h1></CardTitle>
                </Card>
            </div>)
    })
    
    if (rest.length != 0){
        return(
            <Tabs>
               {restaurant}
            </Tabs>
        )
    }else{
        return(
            <Tabs>
                <div className="cards bord" label="None Registered">
                    <h1>why dont you register your first restaurant now</h1>
                </div>
                <div label=""> 
                </div> 
            </Tabs>
        )
    }
   
}
const Manager = (props) =>{// same as making a  menu function
     {
         const manager= props.manager.managers.map((manager)=>{

        
         return (
          <div key={manager.Manager_ID} className="col-12 col-md-12 m-12 tfont text">
              
              
              <Card className="cards shadows row">   
                <CardBody>
                       
                        <CardTitle><b className="colort">.. Name:    </b>{manager.Manager_Name}</CardTitle>
                        <div className="row">
                            <div className=" col-12 col-md-6">
                                <CardText><b className="colort">.. Email:  </b>{manager.Manager_Email}</CardText> 
                            </div>
                            <div className=" col-12 col-md-6">
                                <CardText><b className="colort">..  Joined on:   </b>{manager.Join_date.split("T")[0]}</CardText> 
                            </div>
                            <div className=" col-12 col-md-6">
                                <CardText><b className="colort1">. Restaurants registered:   </b>{props.restaurant.restaurants.length}</CardText> 
                            </div>
                            <div className=" col-12 col-md-12 center">
                                <CardHeader><b>OVERVIEW</b></CardHeader> 
                            </div>
                        </div>
                        {console.log(props.restaurant.restaurants.length)}
                        <Rendermanagersitem rest={props.restaurant.restaurants}/>
                        
                        
                </CardBody>
            </Card>
          </div>
        );
        })
        return(
            <div>
                 <div className="center">
                    <h1>Plz login  </h1>
                </div>
                {manager}
            </div>
        )

    };



}
export  default Manager;
/**/