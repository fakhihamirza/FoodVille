import React, { Component } from 'react';
import {Validate_User} from '../redux/ActionCreators';
import {connect} from 'react-redux'
import { Link, Redirect } from 'react-router-dom';
//binding to this

const mapdispatchtoprops = dispatch => ({   //saray calls r returned
    Validate_User : (values) =>    //validate_user ko call krunge to use dispatch
    {
        dispatch (Validate_User(values))   //sending values to the actioncreator wala validate_user
    }  
}) 


class Login extends Component {
    constructor(props)
    {
        super(props);
        this.state = {
            username : '',
            pass : ''
        };
        this.onSubmit= this.onSubmit.bind(this);
        this.handleUNChange = this.handleUNChange.bind(this);
        this.handlePChange = this.handlePChange.bind(this);
    }

    onSubmit(event){
        //console.log('Current State is: ' + this.state.username + this.state.pass);
        this.props.Validate_User(this.state);
        //console.log('LOGINNN' + this.props.Login_State)
        event.preventDefault();        
    }

    handleUNChange(event){
        this.setState({
            username : event.target.value
        })
    }

    handlePChange(event){
        this.setState({
            pass : event.target.value
        })
    }

    render() {
        if(this.props.login.loggedIn){
            return(
                <div >
                    {this.props.login.user === "Manager"
                      ?   <Redirect to="/manager"/>
                      :  <Redirect to="/user"/>  }
                </div>  
            )
           
        }else{
            return (
                <div className = 'row-content'>
                    <div className= 'col2 center'>
                        <div>
                        <img src='/images/logo.jpg' alt="logo" align = 'left' style={{width:150}}></img>
                        </div>
                        <form onSubmit={this.onSubmit}>
                            <label><b>Username</b></label>
    
                            <input className = 'xx'
                            type="text" 
                            placeholder="Enter Username"  
                            value = {this.state.username} 
                            onChange = {this.handleUNChange}
                            />
    
                            <label><b>Password</b></label>
    
                            <input className = 'xx'
                            type="password" 
                            placeholder="Enter Password"
                            value = {this.state.pass} 
                            onChange = {this.handlePChange}
                            />
                            {this.props.login.error? <div>Username or Password is incorrect</div>:<> </>}
                            <button 
                            type="submit">Login</button>
                           
    
                            <label>
                                <input className = 'xx'
                                type="checkbox"/> Remember me
                            </label>
    
                            <p></p>
                            <label> Don't have and account?</label>
                            <button type="button" onClick={this.onClick}>Register</button>   
                            {/* //link /register  */}
                            
                        </form>
                    </div>
    
                </div>
                
            )
        }
       
    }
}



export default connect (null,mapdispatchtoprops)(Login) 

//connect connects to store (state , dispatch-actions)
