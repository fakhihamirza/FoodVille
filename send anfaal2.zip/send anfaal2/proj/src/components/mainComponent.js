import React, { Component } from 'react';
import Header from './header';
import Footer from './footercomp';
//import logo from '../logo.svg';
import { Switch, Route, Redirect, withRouter} from 'react-router-dom';
import User from './User';
import Manager from './Manager';
import { connect } from 'react-redux';
import { actions } from 'react-redux-form';
import { fetchManagers, fetchRestaurant, logout } from '../redux/ActionCreators';
import Login from './Login'
import Register from './Register';
import User_profile from './User_profile';


const mapStateToProps = state=>{
    
    return{
      managers: state.managers,
      restaurants: state.restaurants,
      login: state.login
    };
  }
  const mapDispatchToProps = dispatch => ({
    fetchManagers: (m)=>{dispatch(fetchManagers(m))},
    fetchRestaurant: (m)=>{dispatch(fetchRestaurant(m))},
    resetregisterform: () => {dispatch(actions.reset('register'))},
    logout: ()=>{dispatch(logout())}
  });
class Main extends Component {
    componentDidMount(){
            this.props.fetchManagers(this.props.m);
            this.props.fetchRestaurant(this.props.m);
    }
   
    componentWillUnmount(){
        if(this.props.login.loggedIn){
            this.props.fetchManagers(this.props.login.Id);
            this.props.fetchRestaurant(this.props.login.Id);
        }
    }
    render(){
       // renders();
        
            console.log(this.props.login)
          

            return(
                
                <div>
                   
                <Header logout={this.props.logout} login={this.props.login}/>
               
                   
                    <Switch location={this.props.location}>
                        
                        <Route exact path="/login" component={()=><Login login={this.props.login}/>}/> 
                        {this.props.login.loggedIn?
                        <> 
                        {
                            this.props.login.user === "Manager"?
                            <>
                            {//this is routes for managers
                            }
                            <Route path="/manager" component={()=><Manager manager={this.props.managers} restaurant={this.props.restaurants} login={this.props.login}/>}/> 
                            <Route path="/addres" component={()=> <User  login={this.props.login}/>}/>
                            </>
                            :
                            <>
                            {//this is routes for users
                            }
                            <Route path="/user" component={()=> <User_profile  login={this.props.login}/>}/>
                            </>
                        }  
                        </>
                        :<>
                           <Redirect to="/login"/>
                        </>
                        }
                        <Redirect to="/login"/>
                    </Switch>
                <Footer/>
                
                </div>
            )
           
    }
         
}



export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Main));