import React, { Component } from 'react'
import {GetUserDetails, fetchAllRestaurants} from '../redux/ActionCreators'
import { Card, CardImg, CardTitle, CardHeader, Breadcrumb, BreadcrumbItem, CardBody, CardText ,Button, Media} from 'reactstrap';
import { connect } from 'react-redux'
import { Switch, Route, Redirect, withRouter} from 'react-router-dom';
const baseUrl='http://localhost:3003/'

const mapDispatchToProps = dispatch => ({   //saray calls r returned
    GetUserDetails : (values) =>    // call krunge to use dispatch
    {
        console.log("Inside mapdispatchtoProps" + values.Id);
        dispatch (GetUserDetails(values))   //sending values to the actioncreator wala validate_user
    },  

    fetchAllRestaurants: (values)=>
    {
        console.log("Inside mapdispatchtoProps Fetch all rest" + values.Id);
        dispatch(fetchAllRestaurants(values))
    }
}) 

const mapStateToProps = state=>{
    
    return{
      LoggedInUser: state.loggedinUser,
      AllRestaurants : state.AllRestaurants
    };
  }


export class User_profile extends Component {
    constructor(props)
    {
        super(props);
        this.state = {
            Id : this.props.login.Id,
            User : this.props.login.user
        };
    }

    componentDidMount(){

    console.log("BEFORE DISPATCH" +this.state.Id)
    this.props.GetUserDetails(this.state)
    this.props.fetchAllRestaurants(this.state);
    }

    render() {
        const x=[] = this.props.AllRestaurants.restaurants;

        const abc = x.map((res)=>{
            return(
                <div>{res.Rest_Name}</div>
            )
        })

        return (
            <div class="row">
                <div class="columnX">
                    <div class = "center">
                        <img src='/images/pic.jpg' alt="Avatar" align = 'center' style={{borderRadius:50 , width : 100, alignSelf : 'center'}}></img>
                    </div>
                    <h1 className = 'userText'>{this.props.LoggedInUser.FName} {this.props.LoggedInUser.LName}</h1>
                </div>
                <div class="columnY">
                    {abc}
                </div>
                
          </div>


        )
    }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(User_profile));

