import * as ActionTypes from './ActionTypes';

const baseUrl='http://localhost:3003/'


//for managers
export const fetchManagers = (a) => (dispatch) => {

    dispatch(managersLoading(true));

    return fetch(baseUrl + 'manager/'+ a )
        .then(response =>{
            if(response.ok){
                console.log("response ok");
                return response;
            }else{
                var error = new Error('Error '+ response.status + ': ' + response.statusText);
                console.log('Error '+ response.status + ': ' + response.statusText);
                error.response=response;
                throw error;
            }
        },
        error =>{
            var errmess= new Error(error.message);
            throw errmess;
        })
        .then(response => response.json())
        .then((data)=> {
            dispatch(addmanager(data))})
        .catch(error => dispatch(managerfailed(error.message)));
};

export const managersLoading= ()=>({
    type: ActionTypes.MANAGER_LOADING
});
export const managerfailed= (errmess)=>({
    type:ActionTypes.MANAGER_FAILED,
    payload: errmess
});
export const addmanager = (managers) => 
   {
    return(
        {
            type: ActionTypes.ADD_MANAGER,
            payload: managers
        }
    );
    
};


//for restaurants
export const fetchRestaurant = (a) => (dispatch) => {

    dispatch(restaurantLoading(true));

    return fetch(baseUrl + 'restaurant/'+a)
        .then(response =>{
            if(response.ok){
                console.log("response ok");
                return response;
            }else{
                var error =new Error('Error '+ response.status + ': ' + response.statusText);
                console.log('Error '+ response.status + ': ' + response.statusText);
                error.response=response;
                throw error;
            }
        },
        error =>{
            var errmess= new Error(error.message);
            throw errmess;
        })
        .then(response => response.json())
        .then((data)=> {
            dispatch(addrestaurant(data))})
        .catch(error => dispatch(restaurantfailed(error.message)));
};

export const restaurantLoading= ()=>({
    type: ActionTypes.RESTAURANT_LOADING
});
export const restaurantfailed= (errmess)=>({
    type:ActionTypes.RESTAURANT_FAILED,
    payload: errmess
});
export const addrestaurant = (restaurant) => 
   {
    
    return(
        {
            type: ActionTypes.ADD_RESTAURANT,
             payload: restaurant
        }
    );
    
};


//for registering manager
export const sendmanager = (values)=> (dispatch) => {
   return fetch(baseUrl + "manager",{
    method: 'POST', // *GET, POST, PUT, DELETE, etc.
    headers: {
      'Content-Type': 'application/json'
      // 'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: JSON.stringify(values) // body data type must match "Content-Type" header
    })
    .then(response =>{
        if(response.ok){
            console.log("response ok");
            return response;
        }else{
            var error =new Error('Error '+ response.status + ': ' + response.statusText);
            console.log('Error '+ response.status + ': ' + response.statusText);
            error.response=response;
            throw error;
        }
    },
    error =>{
        var errmess= new Error(error.message);
        throw errmess;
    })
    .then(()=> {dispatch(sendman(true))})
    .catch(error => dispatch(restaurantfailed(error.message)));
}
export const sendman= ()=>({
    type: ActionTypes.SEND_MANAGER
});



//for validating login
export const Validate_User = (values) => (dispatch) => {

    console.log('YE AARAHA HAI ' + values.username);

    return fetch(baseUrl + 'validate', {
        method : 'POST', headers : {'Content-Type':'application/json'} ,
        body : JSON.stringify(values)
    })
        .then(response =>{
            if(response.ok)
            {
                console.log("response ok");
                console.log(response);
                return response;    //fetched data??
            }
            else
            {
                var error = new Error('Error '+ response.status + ': ' + response.statusText);
                console.log('Error '+ response.status + ': ' + response.statusText);
                error.response=response;
                throw error;
            }
        },error =>{
            var errmess= new Error(error.message);
            throw errmess;
        })
        .then(response => /*{console.log(response.json()) ; return*/ response.json())   //json mai convert
        .then((data)=> {dispatch(Login_Success(data))})   ///data will have return of response.json
        .catch(error => dispatch(Login_Failure(error.message)));
};

export const Login_Success= (data)=>
(   
    console.log('INSIDE LOGIN SUCCESS'+ data),
    {
    type: ActionTypes.LOGIN_SUCCESS,
    payload : data
});

export const Login_Failure= (errmess)=>
(    console.log(errmess),
    {    
    type: ActionTypes.LOGIN_FAILURE,
    payload: errmess
});


export const logout = ()=>({
    type:ActionTypes.LOGOUT
});


//////////// USER PROFILEEEE//////////////
////////////////////////////////
export const GetUserDetails = (values) => (dispatch) => {
    console.log("THIS IS THE USER ID IM GETTING " + values);
    
    
    return fetch(baseUrl + 'userprofile', {
        method : 'POST', headers : {'Content-Type':'application/json'} ,
        body : JSON.stringify(values)
    })
        .then(response =>{
            if(response.ok){
                console.log("response ok");
                return response;
            }else{
                var error = new Error('Error '+ response.status + ': ' + response.statusText);
                console.log('Error '+ response.status + ': ' + response.statusText);
                error.response=response;
                throw error;
            }
        },
        error =>{
            var errmess= new Error(error.message);
            throw errmess;
        })
        .then(response => response.json())
        .then((data)=> {
            dispatch(Load_user_profile(data))})
        .catch(error => dispatch(USER_DISPLAY_FAIL(error.message)));
};

export const Load_user_profile= (data)=>
(   
    console.log('INSIDE USER PROFILEEE'+ data),
    {
    type: ActionTypes.LOAD_USER_PROFILE,
    payload : data
});

export const USER_DISPLAY_FAIL= (errmess)=>
(   
    console.log('USER FAAAIIILLL' + errmess),
    {
    type: ActionTypes.USER_DISPLAY_FAIL,
    payload : errmess
});


//////////////////////////////////  ALLLLL RESTURANTSSSSS  ////////////////////////

export const fetchAllRestaurants = (values) => (dispatch) => {

    console.log("THIS IS THE USER ID IM GETTING " + values);
      
    return fetch(baseUrl + 'AllRestaurants', {
        method : 'POST', headers : {'Content-Type':'application/json'} ,
        body : JSON.stringify(values)
    })
        .then(response =>{
            if(response.ok){
                console.log("response ok");
                return response;
            }else{
                var error = new Error('Error '+ response.status + ': ' + response.statusText);
                console.log('Error '+ response.status + ': ' + response.statusText);
                error.response=response;
                throw error;
            }
        },
        error =>{
            var errmess= new Error(error.message);
            throw errmess;
        })
        .then(response => response.json())
        .then((data)=> {
            dispatch(LOAD_ALL_RESTAURANTS(data))})
        .catch(error => dispatch(LOAD_RESTAURANTS_FAIL(error.message)));
};

export const LOAD_ALL_RESTAURANTS= (data)=>
(   
    console.log('INSIDE USER PROFILEEE'+ data),
    {
    type: ActionTypes.LOAD_ALL_RESTAURANTS,
    payload : data
});

export const LOAD_RESTAURANTS_FAIL= (errmess)=>
(   
    console.log('RESTURAANNTT FAAAIIILLL' + errmess),
    {
    type: ActionTypes.LOAD_RESTAURANTS_FAIL,
    payload : errmess
});


