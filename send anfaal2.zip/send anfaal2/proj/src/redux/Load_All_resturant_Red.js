import * as ActionTypes from './ActionTypes';

export const AllRestaurants =(state = {
    errMess:null,
    restaurants:[]
}, action) =>{
    switch(action.type){
        case ActionTypes.LOAD_ALL_RESTAURANTS:
            
            return {...state, errMess: null, restaurants: action.payload};

        case ActionTypes.LOAD_RESTAURANTS_FAIL:

            return {...state,errMess: action.payload, restaurants: []}

        default:
            return state;
    }
}