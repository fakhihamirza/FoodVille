import * as ActionTypes from './ActionTypes';

const initialState = {
    FName : null,
    LName : null,
    imgsrc : null,
    Address : null,
    errMess : null
}

export const User_Profile_Reducer = (state = initialState , action) =>
{
    switch(action.type)
    {
        case(ActionTypes.LOAD_USER_PROFILE) :
        return{
            ...state,
            FName : action.payload.FirstName,
            LName : action.payload.LastName,
            imgsrc : action.payload.imgsrc,
            Address : action.payload.address

        };
        case ActionTypes.USER_DISPLAY_FAIL:
        return {
        ...state,
        FName : null,
        LName : null,
        imgsrc : null,
        Address : null,
        errMess : action.payload.errMess
      };
        default:
        return state
    }

}

export default User_Profile_Reducer