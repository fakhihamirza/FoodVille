import { createStore, combineReducers, applyMiddleware } from 'redux';
import { Managers } from './managers';
import {User_Profile_Reducer} from './User_Profile_Reducer';
import {createForms} from 'react-redux-form';
import { Restaurant } from './restaurant';
import {AllRestaurants} from './Load_All_resturant_Red'
import { LoginReducer } from './LoginReducer'
import { composeWithDevTools } from 'redux-devtools-extension';
import thunk from 'redux-thunk';
import logger from 'redux-logger';
import { InitialRegister } from './forms';


export const ConfigureStore = () => {
    const store = createStore(
       
       combineReducers({
         managers: Managers,
         restaurants: Restaurant,
         login: LoginReducer,
         loggedinUser: User_Profile_Reducer,
         AllRestaurants : AllRestaurants,
         ...createForms({
            register: InitialRegister,
            user: InitialRegister
         })
       }) ,composeWithDevTools(applyMiddleware(thunk,logger))
       

    );
    return store;
    
}
